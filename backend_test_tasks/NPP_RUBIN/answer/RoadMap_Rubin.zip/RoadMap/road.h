#ifndef ROAD_H
#define ROAD_H
#include <QString>
#include <QList>
#include <QPoint>
#include <QGraphicsItem>
#include <QGraphicsPathItem>
#include <QPen>
#include <QPainter>
#include <QDebug>

namespace M {

class Road: public QGraphicsPathItem
{
	QString _name;
	QList<QPoint> _points;
public:
    explicit Road(QGraphicsItem* parent = nullptr);
    void create();
    void setNAme(const QString& name);
    void setPoint(int x, int y);
    void printAllPoint();
};

}
#endif // ROAD_H
