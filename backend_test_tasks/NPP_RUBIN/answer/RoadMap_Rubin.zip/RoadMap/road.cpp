#include "road.h"


M::Road::Road(QGraphicsItem *parent) : QGraphicsPathItem(parent){
}

void M::Road::create(){
    QPainterPath path;
    auto point = _points.begin();
    path.moveTo(*point);
    point++;
    while(point != _points.end())
    {
        path.lineTo(*point);
        point++;
    }
    setPath(path);
    QPen pen(Qt::black);
    pen.setStyle(Qt::SolidLine);
    pen.setWidth(2);
    this->setPen(pen);
    QBrush brush(Qt::black,Qt::SolidPattern);
    //setPos(path.elementAt(0));
}

void M::Road::setNAme(const QString &name)
{
    _name = name;
}

void M::Road::setPoint(int x, int y){
    _points.push_back(QPoint(x,y));
}

void M::Road::printAllPoint()
{
    // Извлечение всех точек из QGraphicsPathItem
    QVector<QPointF> points;

    for (int i = 0; i < this->path().elementCount(); ++i) {
        QPainterPath::Element element = path().elementAt(i);

        if (element.type == QPainterPath::MoveToElement || element.type == QPainterPath::LineToElement) {
            points.append(element);
        } else if (element.type == QPainterPath::CurveToElement) {
            points.append(element);
        }
    }

    // Вывод всех точек
    for (const QPointF& point : points) {
        qDebug() << "Точка: " << point;
    }

}
