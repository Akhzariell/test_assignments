#ifndef MAP_H
#define MAP_H

#include <QGraphicsView>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include "road.h"
#include <QDebug>
#include <QMouseEvent>
#include <qmath.h>
#include "point.h"


class QGraphicsScene;
class Road;
namespace M {
class Map : public QGraphicsView
{
public:
	QGraphicsScene* _scene;
	QList <Road*> _roads;
	Point _start;
	Point _finish;
	bool setStart;
	bool setFinish;
	Road builtPath;

    explicit Map(QWidget* parent = nullptr);
    ~Map();
    void load(const QString& path);
    Road* searchRoadAtStart();
    QPointF searchNearestPoint(Road* path);

	// QWidget interface
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    double  distancePP(QPointF p1, QPointF p2);

public slots:
    void setStartPoint();
    void setFinishPoint();
    void clearSelect();
    void buildRoute();

};


}

#endif // MAP_H
