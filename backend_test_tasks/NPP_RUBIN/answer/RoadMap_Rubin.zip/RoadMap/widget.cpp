#include "widget.h"
#include "ui_widget.h"
#include <QGridLayout>
#include "map.h"


Widget::Widget(QWidget *parent)
	: QWidget(parent)
	, ui(new Ui::Widget)
{
	ui->setupUi(this);
    ui->graphicsView->load(PRO_FILE_PWD"/ex.json");
    ui->graphicsView->_roads.first()->printAllPoint();
    connect(ui->btn_setStart,&QPushButton::clicked, ui->graphicsView, &M::Map::setStartPoint);
    connect(ui->btn_setFinish,&QPushButton::clicked, ui->graphicsView,  &M::Map::setFinishPoint);
    connect(ui->btn_clear,&QPushButton::clicked, ui->graphicsView, &M::Map::clearSelect);
	connect(ui->btn_buildRoute, &QPushButton::clicked,ui->graphicsView, &M::Map::buildRoute);
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

}

Widget::~Widget()
{
	delete ui;
}

