#ifndef POINT_H
#define POINT_H

#include <QGraphicsItem>
#include <QObject>

namespace M {

class Point : public QGraphicsItem
{
public:
    enum class TYPE {
        START,
        FINISH
    };
    QPoint _p;
    TYPE _type;
    Point(TYPE type,QGraphicsItem* parent = nullptr);

    // QGraphicsItem interface
public:
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

};
}
#endif // POINT_H
