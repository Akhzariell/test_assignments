#include "map.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsScene>

namespace M {
Map::Map(QWidget* parent) : QGraphicsView(parent), _scene(new QGraphicsScene(this)),
    _start(Point::TYPE::START), _finish(Point::TYPE::FINISH)
{
   this->resize(this->parentWidget()->size());
    this->setScene(_scene);
	 _scene->setSceneRect(this->rect());
	_start.setVisible(false);
    _finish.setVisible(false);

    _scene->addItem(&_start);
    _scene->addItem(&_finish);
}


void Map::load(const QString &path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Не удается открыть файл для чтения";
        return;
    }

    QByteArray jsonData = file.readAll();
    file.close();

    QJsonParseError error;
    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData, &error);

    if (jsonDoc.isNull()) {
        qDebug() << "Ошибка чтения JSON файла:" << error.errorString();
            return ;
    }

    if (jsonDoc.isObject()) {
        QJsonObject jsonObj = jsonDoc.object();
        for (const QString &key : jsonObj.keys()) {
            QJsonArray jsonArray = jsonObj.value(key).toArray();
            qDebug() << "Дорога:" << key;
                Road* r = new Road;
            r->setNAme(key);
            for (const QJsonValue &value : jsonArray) {
                QJsonObject obj = value.toObject();
                int x = obj["x"].toInt();
                int y = obj["y"].toInt();
                r->setPoint(x,y);

                qDebug() << "x:" << x << ", y:" << -y;
            }
            r->create();
            // r->setScale(2);
            _roads.push_back(r);
            _scene->addItem(r);
        }
    }
}

Road *Map::searchRoadAtStart()
{
    qDebug() << _roads.size();
    auto itB = _roads.begin();
    auto res = itB;
    double min = qMin(distancePP(_start.pos(), (*itB)->path().elementAt(0)),distancePP(_start.pos(), (*itB)->path().elementAt( (*itB)->path().elementCount()- 1))) ;

    while(itB != _roads.end())
    {
        double beg = distancePP(_start.pos(),  (*itB)->path().elementAt(0));
        double end =  distancePP(_start.pos(),  (*itB)->path().elementAt((*itB)->path().elementCount()-1));
        double curr = beg ;
        if(beg > end)
        {
            (*itB)->setPath((*itB)->path().toReversed());
            curr = end;
        }

        if(min > curr )
        {
            min = curr;
            res = itB;
        }
        itB++;
    }

    return *res;
}

QPointF Map::searchNearestPoint(Road *path)
{
    double min = distancePP(_finish.pos(),  path->path().elementAt(0));
    int index;
    //QPointF p ;
    for (int i = 0; i <  path->path().elementCount(); ++i) {
        double curr = distancePP(_finish.pos(),  path->path().elementAt(i));
        if(min > curr){
            min = curr;
            // p = path->path().elementAt(i);
            index = i;
        }
    }


    if(index > 0)
    {
        double distBtwPoints = distancePP( path->path().elementAt(index),  path->path().elementAt(index - 1)) + min;
        double distPrevPoint = distancePP( _finish.pos(),path->path().elementAt(index -1));
        return (distBtwPoints - distPrevPoint) > min ? path->path().elementAt(index-1): path->path().elementAt(index);
    }


    return   path->path().elementAt(index);
}

void Map::mousePressEvent(QMouseEvent *event)
{
    qDebug() << "глобал pos: x y" << this->mapToGlobal(event->pos()) << "сцена" << event->pos();

        if(setStart)
    {
        _start.setPos(event->pos());
    }

    if(setFinish)
    {
        _finish.setPos( event->pos());
    }
    _scene->update(_scene->sceneRect());
}

void Map::mouseMoveEvent(QMouseEvent *event)
{
    if(setStart)
    {
        _start.setPos(event->pos());
    }

    if(setFinish)
    {
        _finish.setPos(event->pos());
    }
    _scene->update(_scene->sceneRect());
}

double Map::distancePP(QPointF p1, QPointF p2)
{
    return qSqrt(qPow(p2.x() - p1.x(), 2) + qPow(p2.y() - p1.y(), 2));
}

void Map::setStartPoint()
{
    setStart = true;
    setFinish = false;
    _start.setVisible(true);
    // _finish.setVisible(false);
    _scene->update(_scene->sceneRect());
}

void Map::setFinishPoint()
{
    setStart = false;
    setFinish = true;
    // _start.setVisible(false);
    _finish.setVisible(true);
    _scene->update(_scene->sceneRect());
}

void Map::clearSelect()
{
    setFinish = false;
    setStart = false;
    _scene->removeItem(&builtPath);
    builtPath.path().clear();
    _start.setVisible(false);
    _finish.setVisible(false);
    _scene->update(_scene->sceneRect());
}

void Map::buildRoute()
{
    if(_start.isVisible() && _finish.isVisible())
    {
        QPen pen(QColor(150,75,0));
        pen.setWidth(2);
        Road* path = searchRoadAtStart();
        QPointF f = searchNearestPoint(path);

        QPainterPath newPath;
        newPath.moveTo(_start.pos());
        for (int i = 0; i < path->path().elementCount() ; i++) {
            qDebug() << "P" << i << path->path().elementAt(i);
            if(f != path->path().elementAt(i))
                newPath.lineTo(path->path().elementAt(i));
            else break;
        }
        newPath.lineTo(f);
        newPath.lineTo(_finish.pos());
        builtPath.setPath(newPath);
        builtPath.setPen(pen);
        qDebug() << "PATH" <<newPath;
        _scene->addItem(&builtPath);
        _scene->update(_scene->sceneRect());

    }
}
}
