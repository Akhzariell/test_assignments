#!/bin/sh
make -C /Users/kiton/Desktop/RoadMap -f RoadMap.xcodeproj/qt_preprocess.mak
