#!/bin/sh
make -C /Users/kiton/Desktop/RoadMap -f RoadMap.xcodeproj/qt_makeqmake.mak
