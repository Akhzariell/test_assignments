#include "point.h"
#include <QPen>
#include <QPainter>
namespace M {
Point::Point(TYPE type, QGraphicsItem* parent) : QGraphicsItem(parent), _type{type}
{

}

QRectF Point::boundingRect() const
{
    return QRectF();
}

void Point::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option)
    Q_UNUSED(widget)

    QPen pen;

    if(_type == TYPE::START)
    {
        pen.setColor(Qt::green);

    }else
    {
        pen.setColor(Qt::red);
    }

    pen.setWidth(4);

    painter->setPen(pen);
    painter->drawPoint(_p);
}
}
